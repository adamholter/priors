# priors-cli

CLI and MCP server for https://mypriors.com. Docs: https://mypriors.com/cli
